import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Tests for Glossary project.
 *
 * @author Justin Lee
 *
 */
public class GlossaryTest {

    /**
     * Boundary test for fileInput "".
     */
    @Test
    public void boundaryTestSortWordAndDef() {
        SimpleReader input = new SimpleReader1L("data/test1.txt");
        Map<String, String> expectedOutput = new Map1L<>();
        Map<String, String> output = Glossary.sortWordAndDef(input);
        assertEquals(expectedOutput, output);
        input.close();
    }

    /**
     * Routine test for fileInput "Dairy \n milk, eggs, cheese \n Meat \n bacon,
     * steak, ham ".
     */
    @Test
    public void routineTestSortWordAndDef() {
        SimpleReader input = new SimpleReader1L("data/test2.txt");
        Map<String, String> expectedOutput = new Map1L<>();
        expectedOutput.add("Dairy", "milk, eggs, cheese");
        expectedOutput.add("Meat", "bacon, steak, ham");
        Map<String, String> output = Glossary.sortWordAndDef(input);
        assertEquals(expectedOutput, output);
        input.close();
    }

    /**
     * Boundary test for empty Map.
     */
    @Test
    public void boundaryTestConvertMapToQueue() {
        SimpleReader input = new SimpleReader1L("data/test1.txt");
        Map<String, String> inputMap = Glossary.sortWordAndDef(input);
        Queue<String> expectedOutput = new Queue1L<>();
        Queue<String> output = Glossary.convertMapToQueue(inputMap);
        assertEquals(expectedOutput, output);
        input.close();
    }

    /**
     * Routine test for Map {("Dairy", "milk, eggs, cheese"), ("Meat", "bacon,
     * steak ham")}.
     */
    @Test
    public void routineTestConvertMapToQueue() {
        SimpleReader input = new SimpleReader1L("data/test2.txt");
        Map<String, String> inputMap = Glossary.sortWordAndDef(input);
        Queue<String> expectedOutput = new Queue1L<>();
        expectedOutput.enqueue("Dairy");
        expectedOutput.enqueue("Meat");
        Queue<String> output = Glossary.convertMapToQueue(inputMap);
        assertEquals(expectedOutput, output);
        input.close();
    }

    /**
     * Boundary test for empty map and queue.
     */
    @Test
    public void boundaryTestOutputIndex() {
        SimpleReader input = new SimpleReader1L("data/test1.txt");
        Map<String, String> inputMap = Glossary.sortWordAndDef(input);
        Queue<String> inputQueue = Glossary.convertMapToQueue(inputMap);

        SimpleWriter outputStream = new SimpleWriter1L("testOutput/index.html");
        Glossary.outputIndex(outputStream, inputQueue, inputMap, "testOutput");

        SimpleReader testOutputInput = new SimpleReader1L(
                "testOutput/index.html");
        String testOutputString = "";

        while (!testOutputInput.atEOS()) {
            testOutputString += testOutputInput.nextLine();
        }

        String stringExpectedOutput = "<html><head><title> Glossary </title>"
                + "</head><body><h1>Glossary</h1><hr><h2>Index</h2><ul>"
                + "</ul></body></html>";

        assertEquals(stringExpectedOutput, testOutputString);
        input.close();
        outputStream.close();
        testOutputInput.close();
    }

    /**
     * Routine test for map {("Dairy", "milk, eggs, cheese"), ("Meat", "bacon,
     * steak ham")} and queue ("Dairy", "Meat"), "testOutput/".
     */
    @Test
    public void routineTestOutputIndex() {
        SimpleReader input = new SimpleReader1L("data/test2.txt");
        Map<String, String> inputMap = Glossary.sortWordAndDef(input);
        Queue<String> inputQueue = Glossary.convertMapToQueue(inputMap);

        SimpleWriter outputStream = new SimpleWriter1L("testOutput/index.html");
        Glossary.outputIndex(outputStream, inputQueue, inputMap, "testOutput");

        SimpleReader testOutputInput = new SimpleReader1L(
                "testOutput/index.html");
        String testOutputString = "";

        while (!testOutputInput.atEOS()) {
            testOutputString += testOutputInput.nextLine();
        }

        String stringExpectedOutput = "<html><head><title> Glossary </title>"
                + "</head><body><h1>Glossary</h1><hr><h2>Index</h2><ul>"
                + "<li><a href = \"Dairy.html\">Dairy</a></li>"
                + "<li><a href = \"Meat.html\">Meat</a></li>"
                + "</ul></body></html>";

        assertEquals(stringExpectedOutput, testOutputString);
        input.close();
        outputStream.close();
        testOutputInput.close();
    }

    /**
     * Routine test for "Dairy", map {("Dairy", "milk, eggs, cheese"), ("Meat",
     * "bacon, steak ham")} testOutput/Dairy.html.
     */
    @Test
    public void routineTestGenerateDefinitionPage() {
        SimpleReader input = new SimpleReader1L("data/test2.txt");
        Map<String, String> inputMap = Glossary.sortWordAndDef(input);

        Glossary.generateDefinitionPage("Dairy", inputMap,
                "testOutput/Dairy.html");

        SimpleReader testOutput = new SimpleReader1L("testOutput/Dairy.html");
        String testOutputString = "";

        while (!testOutput.atEOS()) {
            testOutputString += testOutput.nextLine();
        }

        String stringExpectedOutput = "<html>"
                + "<head><title>Dairy</title></head><body>"
                + "<h1 style=\"color:Red \"><b><i>Dairy</i></b></h1>"
                + "<p>&emsp;&emsp;milk, eggs, cheese</p><hr>"
                + "<p>Return to <a href = \"index.html\">index</a>.</p>"
                + "</body></html>";

        assertEquals(stringExpectedOutput, testOutputString);

        input.close();
        testOutput.close();
    }

    /**
     * Boundary test for " ", 0.
     */
    @Test
    public void boundaryTestNextWordOrSeparator() {
        String input = " ";
        int position = 0;
        String expectedOutput = " ";

        String output = Glossary.nextWordOrSeparator(input, position);

        assertEquals(expectedOutput, output);

    }

    /**
     * Routine test for "Parrot blue yellow", 0.
     */
    @Test
    public void routineTestNextWordOrSeparator() {
        String input = "Parrot blue yellow";
        int position = 0;
        String expectedOutput = "Parrot";

        String output = Glossary.nextWordOrSeparator(input, position);

        assertEquals(expectedOutput, output);

    }

    /**
     * Boundary test for "".
     */
    @Test
    public void boundaryTestGenerateElements() {
        String input = "";
        Set<Character> inputSet = new Set1L<>();

        Set<Character> expectedOutput = new Set1L<>();

        Glossary.generateElements(input, inputSet);

        assertEquals(expectedOutput, inputSet);

    }

    /**
     * Routine test for ",!. ".
     */
    @Test
    public void routineTestGenerateElements() {
        String input = ",!. ";
        Set<Character> inputSet = new Set1L<>();

        Set<Character> expectedOutput = new Set1L<>();
        expectedOutput.add(',');
        expectedOutput.add('!');
        expectedOutput.add('.');
        expectedOutput.add(' ');

        Glossary.generateElements(input, inputSet);

        assertEquals(expectedOutput, inputSet);

    }

}
